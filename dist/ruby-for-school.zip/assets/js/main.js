(function () {
    pagination(true);
})();
